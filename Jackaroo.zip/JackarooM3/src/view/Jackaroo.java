package view;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.media.AudioClip;
import javafx.scene.input.KeyCode;
import model.Colour;
import model.card.Card;
import model.card.Deck;
import model.card.standard.Standard;
import model.card.standard.Suit;
import model.player.Marble;
import model.player.Player;
import engine.Game;
import engine.board.Board;
import exception.GameException;
import exception.InvalidCardException;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.effect.DropShadow;
import javafx.util.Duration;


public class Jackaroo extends Application {
    private Stage window;
    private Game game;
    private String playerName;
    private String selectedAvatarPath;
    private ArrayList<ToggleButton> Marbles = new ArrayList<>();
    private ToggleGroup cardsGroup;
    private final Map<String, Image> cardImageCache = new HashMap<>();
    private ArrayList<String> avatarnames = new ArrayList<>(Arrays.asList("Zayn","Noura","Faris", "Layla"));
    private ArrayList<String> avatarFiles = new ArrayList<>(Arrays.asList("/avatar1.png", "/avatar2.png", "/avatar3.png", "/avatar4.png"));
    
    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;

        // Sign-up screen
     // Create the root pane
        StackPane root = new StackPane();

        // Load and configure the background image
        Image backgroundImage = new Image("/iiii.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setPreserveRatio(false); // Fill the whole window
        backgroundView.setFitWidth(1300);       // Match your scene size
        backgroundView.setFitHeight(970);       // Match your scene size
        
        
        VBox signupLayout = new VBox(15);
        signupLayout.setAlignment(Pos.CENTER);
        signupLayout.setPadding(new Insets(40));
        
        
        Image logoImage = new Image("/jackaroo_logo.png");
        ImageView view= new ImageView(logoImage);
        view.setFitHeight(340);
        view.setFitWidth(340);
        view.setTranslateY(-40);
        DropShadow shadow = new DropShadow();
        shadow.setRadius(15);
        shadow.setOffsetX(7);
        shadow.setOffsetY(7);
        shadow.setColor(Color.BLACK);
        view.setEffect(shadow);
        Label title = new Label("Welcome to Jackaroo!");
        title.setStyle("-fx-font-family: 'Amiri'; -fx-text-fill: white; -fx-font-size: 40px;");

        Label prompt = new Label("Enter your name:");
        prompt.setStyle("-fx-text-fill: white; -fx-font-size: 25px;");

        TextField nameField = new TextField();
        nameField.setMaxWidth(230);
        
        Button startButton = new Button("Continue");
        nameField.setOnAction(e -> startButton.fire());
        startButton.setOnAction(e -> {
            playerName = nameField.getText().trim();
             try{
            	 game = new Game(playerName);
             }catch(Exception f){
            	 displayAlert("", f.getMessage());
             }
            if (playerName.isEmpty()) {
                displayAlert("","Please enter your name.");
            } else {
                // Proceed to avatar screen
                showAvatarScreen(playerName);
            }
        });
        
        
     
        signupLayout.getChildren().addAll(view,title, prompt, nameField,startButton);
        
        root.getChildren().addAll(backgroundView,signupLayout);

        Scene signupScene = new Scene(root, 1300, 970);
        window.setScene(signupScene);
        window.setTitle("Jackaroo");
        window.show();
    }
    
    
    //avatar screen
    private void showAvatarScreen(String name) {
        VBox avatarLayout = new VBox(20);
        avatarLayout.setAlignment(Pos.CENTER);
        avatarLayout.setPadding(new Insets(40));
        avatarLayout.setStyle("-fx-background-color: #341539;");

        Label avatarLabel = new Label("Choose Your Player:");
        avatarLabel.setStyle("-fx-text-fill: white; -fx-font-size: 30px; -fx-font-weight: bold;");

        ToggleGroup avatarGroup = new ToggleGroup();
        HBox avatarBox = new HBox(10);
        avatarBox.setAlignment(Pos.CENTER);

        

        ArrayList<ToggleButton> toggleButtons = new ArrayList<>();

        for (int i = 0; i < avatarFiles.size(); i++) {
            VBox avatar = new VBox();
            Image avatarImage = new Image(avatarFiles.get(i));
            ImageView avatarView = new ImageView(avatarImage);
            avatarView.setFitHeight(320);
            avatarView.setFitWidth(210);

            ToggleButton toggle = new ToggleButton();
            toggle.setGraphic(avatarView);
            toggle.setToggleGroup(avatarGroup);
            toggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
            toggleButtons.add(toggle); // store the toggle

            toggle.setOnAction(e -> {
                for (Toggle t : avatarGroup.getToggles()) {
                    ToggleButton btn = (ToggleButton) t;
                    btn.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
                }
                ToggleButton selected = (ToggleButton) avatarGroup.getSelectedToggle();
                if (selected != null)
                    selected.setStyle("-fx-background-color: #ffffff33; -fx-border-color: yellow; -fx-border-width: 3px; -fx-border-radius: 4px;");
            });

            Label nameLabel = new Label(avatarnames.get(i));
            nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
            nameLabel.setAlignment(Pos.CENTER);

            avatar.getChildren().addAll(toggle, nameLabel);
            avatar.setAlignment(Pos.CENTER);
            avatarBox.getChildren().add(avatar);
        }

        Button startButton = new Button("Start Game");
        startButton.setPrefWidth(130); // Wider button
        startButton.setStyle("-fx-font-size: 15px; -fx-padding: 8px 12px;");
        
        startButton.setOnAction(e -> {
            Toggle selectedToggle = avatarGroup.getSelectedToggle();
            if (selectedToggle == null) {
                displayAlert("", "Please choose an avatar.");
            } else {
                int avatarIndex = toggleButtons.indexOf(selectedToggle);
                selectedAvatarPath = avatarFiles.get(avatarIndex);
                showWelcomeScene();
            }
        });

        Region spacer = new Region();
        spacer.setPrefHeight(30); // adds vertical space
        avatarLayout.getChildren().addAll(avatarLabel, avatarBox, spacer, startButton);        
        Scene avatarScene = new Scene(avatarLayout, 1300, 970);
        window.setScene(avatarScene);
    }
    
    
    private void showWelcomeScene() {
        String fullText = "أهلاً بك في مجلس الجاكارو! تحرك بحكمة، ووفقك الحظ في رحلتك!";
        
        // Create the root pane
        StackPane root = new StackPane();

        // Load and configure the background image
        Image backgroundImage = new Image("/background.jpg");
        ImageView backgroundView = new ImageView(backgroundImage);
        backgroundView.setPreserveRatio(false); // Fill the whole window
        backgroundView.setFitWidth(1300);       // Match your scene size
        backgroundView.setFitHeight(970);       // Match your scene size

     // Welcome text
        Label welcomeText = new Label("أهلًا وسهلًا بك في لعبة الجاكارو!");
        welcomeText.setStyle("-fx-font-size: 40px; -fx-text-fill: white; -fx-font-weight: bold;");

        VBox textContainer = new VBox(welcomeText);
        textContainer.setAlignment(Pos.TOP_CENTER);
        textContainer.setPadding(new Insets(300, 0, 0, 0)); // Push down from top
        
        // Add background and content
        root.getChildren().addAll(backgroundView, textContainer);
        
        // Typing sound clip (ensure your sound file is placed correctly in the resources folder)
        AudioClip clickSound = new AudioClip(getClass().getResource("/click.wav").toExternalForm());

        // Timeline for typing effect
        Timeline typingTimeline = new Timeline();
        Duration delayBetweenChars = Duration.millis(120);

        for (int i = 0; i <= fullText.length(); i++) {
            final int index = i;
            KeyFrame keyFrame = new KeyFrame(delayBetweenChars.multiply(i), e -> {
                welcomeText.setText(fullText.substring(0, index));
                clickSound.play();
            });
            typingTimeline.getKeyFrames().add(keyFrame);
        }

        typingTimeline.setOnFinished(e -> {
            PauseTransition pause = new PauseTransition(Duration.seconds(1));
            pause.setOnFinished(ev -> showGameScreen(playerName, selectedAvatarPath )); // Replace with player's name
            pause.play();
        });

        typingTimeline.play();

        Scene scene = new Scene(root, 1300, 970);
        window.setScene(scene);
    }



    // Placeholder for the main game screen
    private void showGameScreen(String name, String avatarPath) {
    	int index=0;
    	
    	ArrayList<String> cpuNames = new ArrayList<>(Arrays.asList(playerName));
    	int j=0;
    	for(String s: avatarFiles){
    		if(!s.equals(selectedAvatarPath)){
    			cpuNames.add(avatarnames.get(j));
    		}
    		j++;
    	}
    	
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #341539;");
        root.setPadding(new Insets(10));

        // Turn information at the top
        Label turnInfo = new Label("Current Turn: " + cpuNames.get(game.getCurrentPlayerIndex()) + 
                              " | Next: " + cpuNames.get((game.getCurrentPlayerIndex()+1)%4));
        turnInfo.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        HBox turnBar = new HBox(turnInfo);
        turnBar.setAlignment(Pos.CENTER);
        turnBar.setPadding(new Insets(0, 0, 10, 0));
        
        // Main game area (center)
        
     // Create the firepit image
        ImageView firepit;
        if(game.getFirePit().isEmpty()){
        	firepit = new ImageView(new Image("/firepitlogo.png"));
        	firepit.setFitWidth(70);
            firepit.setFitHeight(70);
        }else{
        	firepit = new ImageView(getCardImage(game.getFirePit().get(game.getFirePit().size()-1)));
        	firepit.setFitWidth(90);
            firepit.setFitHeight(130);
        }
        
        
        GridPane board = createHollowGameBoard();
        StackPane boardContainer = new StackPane(board);
        boardContainer.setPadding(new Insets(10));
        
        // CPU 2 (Top)
        VBox cpu2Box = createCPUBox(cpuNames.get(2), false, false, game.getPlayers().get(2).getHand().size());
        GridPane cpu2Home = createHomeZoneSquare(game.getPlayers().get(2).getColour());
        cpu2Home.setAlignment(Pos.CENTER);
        
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                if (index < game.getPlayers().get(2).getMarbles().size()) {
                    // Get the StackPane cell at (col, row)
                	Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(2).getColour()))); // Or your player's color
                	circle.setStroke(Color.BLACK);  // border color
                	circle.setStrokeWidth(1);       // border thickness
                	ToggleButton marbleToggle = new ToggleButton();
        			marbleToggle.setGraphic(circle);
        			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        			marbleToggle.setPadding(Insets.EMPTY);
        			marbleToggle.setUserData(game.getPlayers().get(2).getMarbles().get(index));
        			
        			//Visual feedback when selected
        			if(game.getCurrentPlayerIndex()==0){
        				marbleToggle.setOnAction(e -> {
        	                if (marbleToggle.isSelected()) {
        	                    Marble selected = (Marble) marbleToggle.getUserData();
        	                    try {
        	                        game.selectMarble(selected);
        	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
        	                    } catch (Exception ex) {
        	                        marbleToggle.setSelected(false);
        	                        displayAlert("", ex.getMessage());
        	                    }
        	                } else {
        	                    Marble deselected = (Marble) marbleToggle.getUserData();
        	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
        	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        	                }
        	            });        			}
        	        
        			
            		// Place marble in the cell at (col, row)
        	        Marbles.add(marbleToggle);
            		StackPane cell = getCellAt(cpu2Home,col,row);
            		cell.getChildren().add(marbleToggle);
                    index++;
                        }
                    }
                }
            
        HBox topRow = new HBox(20, cpu2Box, cpu2Home);
        topRow.setAlignment(Pos.CENTER);
        VBox topPanel = new VBox(5, turnBar, topRow);
        topPanel.setAlignment(Pos.CENTER);
        root.setTop(topPanel);

        // Player (Bottom)
        ImageView deck;
        
        if(Deck.getPoolSize()==0){
        	deck = new ImageView();
        }else{
        	deck = new ImageView(new Image("/cardBack.png"));
        }
        deck.setFitWidth(85);
        deck.setFitHeight(120);
        Label deckn = new Label("DECK");
        deckn.setStyle("-fx-text-fill: white; -fx-font-size: 20px;");
        VBox deckk = new VBox(3, deck, deckn);
        deckk.setAlignment(Pos.CENTER);
        deckk.setTranslateX(-45);
        
        ImageView avatar = new ImageView(new Image(avatarPath));
        avatar.setFitHeight(130);
        avatar.setFitWidth(100);
        Label playerName = new Label(name);
        playerName.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        VBox playerInfo = new VBox(3, avatar, playerName);
        playerInfo.setAlignment(Pos.CENTER);

        HBox cardRow = createCardRow();
        cardRow.setAlignment(Pos.CENTER);
        
        GridPane playerHome = createHomeZoneSquare(game.getPlayers().get(0).getColour());
        
        index=0;
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                if (index < game.getPlayers().get(0).getMarbles().size()) {
                    // Get the StackPane cell at (col, row)
                	Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(0).getColour()))); // Or your player's color
                	circle.setStroke(Color.BLACK);  // border color
                	circle.setStrokeWidth(1);       // border thickness
                	ToggleButton marbleToggle = new ToggleButton();
        			marbleToggle.setGraphic(circle);
        			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        			marbleToggle.setPadding(Insets.EMPTY);
        			marbleToggle.setUserData(game.getPlayers().get(0).getMarbles().get(index));

        	        //Visual feedback when selected
        			if(game.getCurrentPlayerIndex()==0){
        				marbleToggle.setOnAction(e -> {
        	                if (marbleToggle.isSelected()) {
        	                    Marble selected = (Marble) marbleToggle.getUserData();
        	                    try {
        	                        game.selectMarble(selected);
        	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
        	                    } catch (Exception ex) {
        	                        marbleToggle.setSelected(false);
        	                        displayAlert("", ex.getMessage());
        	                    }
        	                } else {
        	                    Marble deselected = (Marble) marbleToggle.getUserData();
        	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
        	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        	                }
        	            });
        			}
        	        
        	        
        	        Marbles.add(marbleToggle);
        			StackPane cell = getCellAt(playerHome, col, row);
            		cell.getChildren().add(marbleToggle);
                    index++;
                        }
                    }
                }
        
        VBox homeandbutton = new VBox(35);
        homeandbutton.setAlignment(Pos.CENTER);

        homeandbutton.getChildren().add(playerHome);
        Button play =new Button("play Turn");
        
        if (game.getCurrentPlayerIndex()==0){
        	play.setOnAction(e -> {
        		play();
        	});
        	
        	
        	homeandbutton.getChildren().add(play);
        }
        	
        // Bottom layout with proper spacing
        HBox bottomRow = new HBox(30,deckk, playerInfo, cardRow, homeandbutton);
        bottomRow.setAlignment(Pos.CENTER);
        bottomRow.setPadding(new Insets(15, 0, 0, 0));
        bottomRow.setTranslateX(-45);
        root.setBottom(bottomRow);

        // CPU 1 (Left)
        VBox cpu1Box = createCPUBox(cpuNames.get(1), true, true, game.getPlayers().get(1).getHand().size());
        GridPane cpu1Home = createHomeZoneSquare(game.getPlayers().get(1).getColour());
        cpu1Home.setAlignment(Pos.CENTER);
        
        index=0;
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                if (index < game.getPlayers().get(1).getMarbles().size()) {
                	// Get the StackPane cell at (col, row)
                	Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(1).getColour()))); // Or your player's color
                	circle.setStroke(Color.BLACK);  // border color
                	circle.setStrokeWidth(1);       // border thickness
                	ToggleButton marbleToggle = new ToggleButton();
        			marbleToggle.setGraphic(circle);
        			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        			marbleToggle.setPadding(Insets.EMPTY);
        			marbleToggle.setUserData(game.getPlayers().get(1).getMarbles().get(index));
        			
        			//Visual feedback when selected
        			if(game.getCurrentPlayerIndex()==0){
        				marbleToggle.setOnAction(e -> {
        	                if (marbleToggle.isSelected()) {
        	                    Marble selected = (Marble) marbleToggle.getUserData();
        	                    try {
        	                        game.selectMarble(selected);
        	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
        	                    } catch (Exception ex) {
        	                        marbleToggle.setSelected(false);
        	                        displayAlert("", ex.getMessage());
        	                    }
        	                } else {
        	                    Marble deselected = (Marble) marbleToggle.getUserData();
        	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
        	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        	                }
        	            });        			}
        			
            		// Place marble in the cell at (col, row)
        	        Marbles.add(marbleToggle);
            		StackPane cell = getCellAt(cpu1Home, col, row);
            		cell.getChildren().add(marbleToggle);
                    index++;
                        }
                    }
                }
        
        VBox leftPanel = new VBox(20, cpu1Box, cpu1Home);
        leftPanel.setAlignment(Pos.CENTER);
        leftPanel.setPadding(new Insets(0, 20, 0, 0)); // Right padding to avoid overlap
        root.setLeft(leftPanel);
        
        

        // CPU 3 (Right)
        VBox cpu3Box = createCPUBox(cpuNames.get(3), true, false, game.getPlayers().get(3).getHand().size());
        GridPane cpu3Home = createHomeZoneSquare(game.getPlayers().get(3).getColour());
        
        index=0;
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                if (index < game.getPlayers().get(3).getMarbles().size()) {
                	// Get the StackPane cell at (col, row)
                	Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(3).getColour()))); // Or your player's color
                	circle.setStroke(Color.BLACK);  // border color
                	circle.setStrokeWidth(1);       // border thickness
                	ToggleButton marbleToggle = new ToggleButton();
        			marbleToggle.setGraphic(circle);
        			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        			marbleToggle.setPadding(Insets.EMPTY);
        			marbleToggle.setUserData(game.getPlayers().get(3).getMarbles().get(index));
        			
        			//Visual feedback when selected
        			if(game.getCurrentPlayerIndex()==0){
        				marbleToggle.setOnAction(e -> {
        	                if (marbleToggle.isSelected()) {
        	                    Marble selected = (Marble) marbleToggle.getUserData();
        	                    try {
        	                        game.selectMarble(selected);
        	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
        	                    } catch (Exception ex) {
        	                        marbleToggle.setSelected(false);
        	                        displayAlert("", ex.getMessage());
        	                    }
        	                } else {
        	                    Marble deselected = (Marble) marbleToggle.getUserData();
        	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
        	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        	                }
        	            });
        			}
        	        
            		// Place marble in the cell at (col, row)
        	        Marbles.add(marbleToggle);
            		StackPane cell = getCellAt(cpu3Home, col, row);
            		cell.getChildren().add(marbleToggle);
                    index++;
                        }
                    }
                }
        
        VBox rightPanel = new VBox(20, cpu3Box, cpu3Home);
        rightPanel.setAlignment(Pos.CENTER);
        rightPanel.setPadding(new Insets(0, 0, 0, 20)); // Left padding to avoid overlap
        root.setRight(rightPanel);

        // Board in center with proper constraints
        board.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        StackPane centerContainer = new StackPane(board,firepit);
        centerContainer.setPadding(new Insets(10));
        root.setCenter(centerContainer);

        Scene scene = new Scene(root, 1300, 970);
        	scene.setOnKeyPressed(event -> {
                if (event.getCode() == KeyCode.F) {
                    try {
						game.fieldMarble();
						showGameScreen(name, selectedAvatarPath);
					} catch (Exception e) {
						displayAlert("", e.getMessage());
					}
                }
            });
        
        window.setScene(scene);
    }

    private GridPane createHollowGameBoard() {
    	ArrayList<Point2D> topsafe = new ArrayList<>();
    	topsafe.addAll(Arrays.asList(new Point2D(1, 13), new Point2D(2, 13), new Point2D(3, 13), new Point2D(4,13)));
    	
    	ArrayList<Point2D> bottomsafe = new ArrayList<>();
    	bottomsafe.addAll(Arrays.asList(new Point2D(24, 12), new Point2D(23, 12), new Point2D(22, 12), new Point2D(21,12)));
    	
    	ArrayList<Point2D> leftsafe= new ArrayList<>();
    	leftsafe.addAll(Arrays.asList(new Point2D(12,1),new Point2D(12,2),new Point2D(12,3),new Point2D(12,4)));
    	
    	ArrayList<Point2D> rightsafe= new ArrayList<>();
    	rightsafe.addAll(Arrays.asList(new Point2D(13,24),new Point2D(13,23),new Point2D(13,22),new Point2D(13,21)));
    	
    	
    	GridPane board = new GridPane();
        board.setHgap(2);
        board.setVgap(2);
        board.setAlignment(Pos.CENTER);
        board.setPrefSize(900, 700); // Adjusted size

        for (int row = 0; row < 26; row++) {
            for (int col = 0; col < 26; col++) {
                // Determine if the current cell is a special zone

                boolean isTopSafe = (col == 13 && row >= 1 && row <= 4);  // Top Player (Red) vertical line
                boolean isBottomSafe = (col == 12 && row >= 21 && row <= 24); // Bottom Player (Green) vertical line
                boolean isLeftSafe = (row == 12 && col >= 1 && col <= 4);  // Left Player (Blue) horizontal line
                boolean isRightSafe = (row == 13 && col >= 21 && col <= 24); // Right Player (Yellow) horizontal line
                

                // Skip hollow inside unless it's a special cell
                if ((row > 0 && row < 25 && col > 0 && col < 25) &&
                    !isTopSafe && !isBottomSafe && !isLeftSafe && !isRightSafe) {
                    continue;
                }

                StackPane cell = new StackPane();
                cell.setPrefSize(25, 25); // Slightly smaller cells
             // Clip it with a circle
               // Circle clip = new Circle(10); // Radius = half of width/height
               // clip.centerXProperty().bind(cell.widthProperty().divide(2));
              //  clip.centerYProperty().bind(cell.heightProperty().divide(2));
              //  cell.setClip(clip);

                // Optional: Add a border effect to simulate a visible circle
                cell.setStyle("-fx-border-color: black; -fx-border-width: 4px; -fx-background-color: black;");

                // Assign colors to the special cells
                if (isTopSafe)
                    cell.setStyle("-fx-background-color: " + toHex(game.getPlayers().get(2).getColour()) + ";");
                else if (isBottomSafe)
                    cell.setStyle("-fx-background-color: " + toHex(game.getPlayers().get(0).getColour()) + ";");
                else if (isLeftSafe)
                    cell.setStyle("-fx-background-color: " + toHex(game.getPlayers().get(1).getColour()) + ";");
                else if (isRightSafe)
                    cell.setStyle("-fx-background-color: " + toHex(game.getPlayers().get(3).getColour()) + ";");
                else {
                    cell.setStyle("-fx-background-color: white; -fx-border-color: gray;");
                }

                board.add(cell, col, row);
            }
        }
        
        for (int i = 0; i < 100; i++) {
            if (game.getBoard().getTrack().get(i).getMarble() != null) {
                Point2D pos = trackList().get(i);
                int col = (int) pos.getY(); // GridPane: column is Y
                int row = (int) pos.getX(); // GridPane: row is X

                Marble marble = game.getBoard().getTrack().get(i).getMarble();
                Circle circle = new Circle(10, Color.web(toHexM(marble.getColour())));
                circle.setStroke(Color.BLACK);  // border color
                circle.setStrokeWidth(1);       // border thickness

                ToggleButton marbleToggle = new ToggleButton();
                marbleToggle.setGraphic(circle);
                marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
                marbleToggle.setPadding(Insets.EMPTY);
                marbleToggle.setUserData(marble); // Store marble object

                if (game.getCurrentPlayerIndex() == 0) {
                    marbleToggle.setOnAction(e -> {
                        if (marbleToggle.isSelected()) {
                            Marble selected = (Marble) marbleToggle.getUserData();
                            try {
                                game.selectMarble(selected);
                                marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
                            } catch (Exception ex) {
                                marbleToggle.setSelected(false);
                                displayAlert("", ex.getMessage());
                            }
                        } else {
                            Marble deselected = (Marble) marbleToggle.getUserData();
                            game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
                            marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
                        }
                    });
                }

                Marbles.add(marbleToggle);
                StackPane cell = getCellAt(board, col, row);
                cell.getChildren().add(marbleToggle);
            }
        }

        
        for(int i=0; i<4; i++){
        	if(game.getBoard().getSafeZone(game.getPlayers().get(0).getColour()).get(i).getMarble()!=null){
        		Point2D pos = bottomsafe.get(i);
        		int col = (int) pos.getY(); // GridPane: column is Y
        		int row = (int) pos.getX(); // GridPane: row is X
        		Circle circle = new Circle(10,Color.web(toHexM(game.getPlayers().get(0).getColour())));
        		circle.setStroke(Color.BLACK);  // border color
            	circle.setStrokeWidth(1);       // border thickness
    			ToggleButton marbleToggle = new ToggleButton();
    			marbleToggle.setGraphic(circle);
    			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
    			marbleToggle.setPadding(Insets.EMPTY);
    			marbleToggle.setUserData(game.getBoard().getSafeZone(game.getPlayers().get(0).getColour()).get(i).getMarble());

    	        //Visual feedback when selected
    			if(game.getCurrentPlayerIndex()==0){
    				marbleToggle.setOnAction(e -> {
    	                if (marbleToggle.isSelected()) {
    	                    Marble selected = (Marble) marbleToggle.getUserData();
    	                    try {
    	                        game.selectMarble(selected);
    	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
    	                    } catch (Exception ex) {
    	                        marbleToggle.setSelected(false);
    	                        displayAlert("", ex.getMessage());
    	                    }
    	                } else {
    	                    Marble deselected = (Marble) marbleToggle.getUserData();
    	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
    	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
    	                }
    	            });
    			}
    		
    	        Marbles.add(marbleToggle);
    			StackPane cell = getCellAt(board, col, row);
        		cell.getChildren().add(marbleToggle);
        		
        	}
        }
        
       for(int i=0; i<4;i++){
        		if(game.getBoard().getSafeZone(game.getPlayers().get(1).getColour()).get(i).getMarble()!=null){
        			Point2D pos = leftsafe.get(i);
            		int col = (int) pos.getY(); // GridPane: column is Y
            		int row = (int) pos.getX(); // GridPane: row is X
        			// Create cpu marble
            		Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(1).getColour()))); // Or your player's color
            		circle.setStroke(Color.BLACK);  // border color
                	circle.setStrokeWidth(1);       // border thickness
                	ToggleButton marbleToggle = new ToggleButton();
        			marbleToggle.setGraphic(circle);
        			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        			marbleToggle.setPadding(Insets.EMPTY);
        			marbleToggle.setUserData(game.getBoard().getSafeZone(game.getPlayers().get(1).getColour()).get(i).getMarble());

        	        //Visual feedback when selected
        			if(game.getCurrentPlayerIndex()==0){
        				marbleToggle.setOnAction(e -> {
        	                if (marbleToggle.isSelected()) {
        	                    Marble selected = (Marble) marbleToggle.getUserData();
        	                    try {
        	                        game.selectMarble(selected);
        	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
        	                    } catch (Exception ex) {
        	                        marbleToggle.setSelected(false);
        	                        displayAlert("", ex.getMessage());
        	                    }
        	                } else {
        	                    Marble deselected = (Marble) marbleToggle.getUserData();
        	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
        	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        	                }
        	            });
        			}
        			
        	        
        	        Marbles.add(marbleToggle);
            		// Place marble in the cell at (col, row)
            		StackPane cell = getCellAt(board, col, row);
            		cell.getChildren().add(marbleToggle);
        		}
        }
       
       for(int i=0; i<4;i++){
   		if(game.getBoard().getSafeZone(game.getPlayers().get(2).getColour()).get(i).getMarble()!=null){
   			Point2D pos = topsafe.get(i);
       		int col = (int) pos.getY(); // GridPane: column is Y
       		int row = (int) pos.getX(); // GridPane: row is X
   			// Create cpu marble
       		Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(2).getColour()))); // Or your player's color
       		circle.setStroke(Color.BLACK);  // border color
        	circle.setStrokeWidth(1);       // border thickness
        	ToggleButton marbleToggle = new ToggleButton();
			marbleToggle.setGraphic(circle);
			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
			marbleToggle.setPadding(Insets.EMPTY);
			marbleToggle.setUserData(game.getBoard().getSafeZone(game.getPlayers().get(2).getColour()).get(i).getMarble());

	        //Visual feedback when selected
			if(game.getCurrentPlayerIndex()==0){
				marbleToggle.setOnAction(e -> {
	                if (marbleToggle.isSelected()) {
	                    Marble selected = (Marble) marbleToggle.getUserData();
	                    try {
	                        game.selectMarble(selected);
	                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
	                    } catch (Exception ex) {
	                        marbleToggle.setSelected(false);
	                        displayAlert("", ex.getMessage());
	                    }
	                } else {
	                    Marble deselected = (Marble) marbleToggle.getUserData();
	                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
	                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
	                }
	            });
			}
	        Marbles.add(marbleToggle);
       		// Place marble in the cell at (col, row)
       		StackPane cell = getCellAt(board, col, row);
       		cell.getChildren().add(marbleToggle);
   		}
   }
       
       for(int i=0; i<4;i++){
   		if(game.getBoard().getSafeZone(game.getPlayers().get(3).getColour()).get(i).getMarble()!=null){
   			Point2D pos = rightsafe.get(i);
       		int col = (int) pos.getY(); // GridPane: column is Y
       		int row = (int) pos.getX(); // GridPane: row is X
   			// Create cpu marble
       		Circle circle = new Circle(10, Color.web(toHexM(game.getPlayers().get(3).getColour()))); // Or your player's color
       		circle.setStroke(Color.BLACK);  // border color
        	circle.setStrokeWidth(1);       // border thickness
        	ToggleButton marbleToggle = new ToggleButton();
			marbleToggle.setGraphic(circle);
			marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
			marbleToggle.setPadding(Insets.EMPTY);
			marbleToggle.setUserData(game.getBoard().getSafeZone(game.getPlayers().get(3).getColour()).get(i).getMarble());

	        //Visual feedback when selected
			 if(game.getCurrentPlayerIndex()==0){
				 marbleToggle.setOnAction(e -> {
		                if (marbleToggle.isSelected()) {
		                    Marble selected = (Marble) marbleToggle.getUserData();
		                    try {
		                        game.selectMarble(selected);
		                        marbleToggle.setStyle("-fx-background-color: #ffffff33; -fx-border-color: black; -fx-border-width: 3px;");
		                    } catch (Exception ex) {
		                        marbleToggle.setSelected(false);
		                        displayAlert("", ex.getMessage());
		                    }
		                } else {
		                    Marble deselected = (Marble) marbleToggle.getUserData();
		                    game.getPlayers().get(0).getSelectedMarbles().remove(deselected);
		                    marbleToggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
		                }
		            });
			 }
			
	        
	        Marbles.add(marbleToggle);
       		// Place marble in the cell at (col, row)
       		StackPane cell = getCellAt(board, col, row);
       		cell.getChildren().add(marbleToggle);
   		}
   }
        
        return board;
    }
    
    
    private StackPane getCellAt(GridPane board, int col, int row) {
        for (javafx.scene.Node node : board.getChildren()) {
            if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
                return (StackPane) node;
            }
        }
        return null; // not found
    }
    
    public static ArrayList<Point2D> trackList() {
        ArrayList<Point2D> track = new ArrayList<>();

        // Top edge: (25,10) to (25,0)
        for (int col = 10; col >= 0; col--) {
            track.add(new Point2D(25, col));
        }

        // Left edge: (24,0) to (0,0)
        for (int row = 24; row >= 0; row--) {
            track.add(new Point2D(row, 0));
        }

        // Bottom edge: (0,1) to (0,25)
        for (int col = 1; col <= 25; col++) {
            track.add(new Point2D(0, col));
        }

        // Right edge: (1,25) to (25,25)
        for (int row = 1; row <= 25; row++) {
            track.add(new Point2D(row, 25));
        }

        // Top edge (back to starting column): (25,24) to (25,11)
        for (int col = 24; col >= 11; col--) {
            track.add(new Point2D(25, col));
        }

        return track;
    }



    private VBox createCPUBox(String name, boolean vertical, boolean avatarOnLeft, int handsize) {
        Label nameLabel = new Label(name);
        nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");

        ImageView avatar = new ImageView(new Image("/CPUpfp.png"));
        avatar.setFitHeight(50);
        avatar.setFitWidth(50);

        VBox box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(5)); // smaller padding to bring closer to board

        if (vertical) {
            VBox cardColumn = new VBox(); // tighter spacing
            for (int i = 0; i < handsize; i++) {
                ImageView cardBack = new ImageView("/cardBack.png");
                cardBack.setFitHeight(120);  // larger cards
                cardBack.setFitWidth(85);
                //cardBack.setRotate(90); // landscape
                cardColumn.getChildren().add(cardBack);
            }
            for (int i = 0; i < 4-handsize; i++) {
                ImageView cardBack = new ImageView();
                cardBack.setFitHeight(120);  // larger cards
                cardBack.setFitWidth(85);
                //cardBack.setRotate(90); // landscape
                cardColumn.getChildren().add(cardBack);
            }
            
            
            VBox avatarAndName = new VBox(5, avatar, nameLabel);
            avatarAndName.setAlignment(Pos.CENTER);

            HBox horizontalLayout;
            if (avatarOnLeft) {
                horizontalLayout = new HBox(5, avatarAndName, cardColumn); // avatar on left
            } else {
                horizontalLayout = new HBox(5, cardColumn, avatarAndName); // avatar on right (CPU 3)
            }
            horizontalLayout.setAlignment(Pos.CENTER);
            box.getChildren().add(horizontalLayout);

        } else {
            // CPU 2
            HBox cardRow = new HBox();
            for (int i = 0; i < handsize; i++) {
                ImageView cardBack = new ImageView(new Image("/cardBack.png"));
                cardBack.setFitHeight(120);
                cardBack.setFitWidth(85);
                cardRow.getChildren().add(cardBack);
            }
            for (int i = 0; i < 4-handsize; i++) {
                ImageView cardBack = new ImageView();
                cardBack.setFitHeight(120);
                cardBack.setFitWidth(85);
                cardRow.getChildren().add(cardBack);
            }
            cardRow.setAlignment(Pos.CENTER);
            VBox nameavatar = new VBox(5,avatar, nameLabel);
            HBox topLayout = new HBox(5,nameavatar, cardRow); // avatar and name above cards
            topLayout.setAlignment(Pos.CENTER);
            box.getChildren().add(topLayout);
        }

        return box;
    }



    private HBox createCardRow() {
    	cardsGroup = new ToggleGroup();
    	HBox row = new HBox(10);
    	
        for (int i = 0; i < game.getPlayers().get(0).getHand().size(); i++) {
        	ImageView image = new ImageView(getCardImage(game.getPlayers().get(0).getHand().get(i)));
            image.setFitHeight(120);
            image.setFitWidth(85);

            ToggleButton cardstoggle = new ToggleButton();
            cardstoggle.setGraphic(image);
            cardstoggle.setToggleGroup(cardsGroup);
            cardstoggle.setUserData(game.getPlayers().get(0).getHand().get(i)); // Store card
            cardstoggle.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
            cardstoggle.setPadding(Insets.EMPTY);
            
            cardstoggle.setOnAction(e -> {
                for (Toggle t : cardsGroup.getToggles()) {
                    ToggleButton btn = (ToggleButton) t;
                    btn.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
                }
                
              //select card
            	ToggleButton selected = (ToggleButton) cardsGroup.getSelectedToggle();
            	if(selected!=null){
            		selected.setStyle("-fx-background-color: #ffffff33; -fx-border-color: transparent; -fx-border-width: 6px; -fx-border-radius: 35px;");
            		if(game.getCurrentPlayerIndex()==0){
            			Card c = (Card) selected.getUserData();
                    	try {
                			game.selectCard(c);
                		} catch (Exception e1) {
                			displayAlert("", e1.getMessage());
                		}
            		}
                	
            	}else{
            		if(game.getCurrentPlayerIndex()==0){
            			game.getPlayers().get(0).setSelectedCard(null);
            		}
            	}
            });
        	
            row.getChildren().add(cardstoggle);
        }
        
        for (int i = 0; i < 4-game.getPlayers().get(0).getHand().size(); i++) {
        	ImageView card = new ImageView();
        	card.setFitHeight(120);
            card.setFitWidth(85);
            row.getChildren().add(card);
        }
        return row;
    }
    
    
    
    private GridPane createHomeZoneSquare(Colour color) {
        GridPane homeZone = new GridPane();
        homeZone.setHgap(4);
        homeZone.setVgap(4);
        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 2; c++) {
                StackPane cell = new StackPane();
                cell.setPrefSize(25, 25);
                cell.setStyle("-fx-background-color: " + toHex(color) + ";");
                homeZone.add(cell, c, r);
            }
        }
        return homeZone;
    }
    
    
    private void showWinnerScreen(Colour color){
    	// Root layout
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: white;");

        // Title label
        Label winLabel = new Label("WINNER! ");
        winLabel.setStyle("-fx-font-size: 60px; -fx-text-fill: black; -fx-font-weight: bold;");

        // Glowing circle for the winner
        Circle glowingCircle = new Circle(100, Color.web(toHex(color)));
        glowingCircle.setEffect(new DropShadow(60, Color.web(toHex(color))));
        
        // Winner text
        Label winnerColorLabel = new Label(color.name() + " Player Wins!");
        winnerColorLabel.setStyle("-fx-font-size: 40px;" +"-fx-text-fill: " + toHex(color) + ";" +"-fx-font-weight: bold;");


        VBox centerText = new VBox(20, winLabel, glowingCircle, winnerColorLabel);
        centerText.setAlignment(Pos.CENTER);

        // Play Again Button
        Button playAgain = new Button("Play Again");
        playAgain.setStyle("-fx-font-size: 20px; -fx-background-color: grey;");
        playAgain.setOnAction(e -> start(window)); // Restart your game
        playAgain.setVisible(false); // Hide initially

        centerText.getChildren().add(playAgain);

        // Confetti animation (fake using circles falling)
        Pane confettiLayer = new Pane();
        for (int i = 0; i < 80; i++) {
            Circle confetti = new Circle(5, Color.hsb(Math.random() * 360, 1, 1));
            confetti.setLayoutX(Math.random() * 1200);
            confetti.setLayoutY(Math.random() * -800);
            confettiLayer.getChildren().add(confetti);

            TranslateTransition drop = new TranslateTransition(Duration.seconds(5 + Math.random() * 3), confetti);
            drop.setToY(1000);
            drop.setCycleCount(Animation.INDEFINITE);
            drop.setDelay(Duration.seconds(Math.random() * 2));
            drop.play();
        }

        root.getChildren().addAll(confettiLayer, centerText);
        
        // Delay the Play Again button (3 seconds)
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        delay.setOnFinished(e -> playAgain.setVisible(true));
        delay.play();

        Scene winScene = new Scene(root, 1200, 900);
        window.setScene(winScene);
    }

    private String toHex(Colour c) {
        switch (c) {
            case RED: return "#FF6961";
            case BLUE: return "#AEC6CF";
            case GREEN: return "#77DD77";
            case YELLOW: return "#FDFD96";
            default: return "#cccccc";
        }
    }
    
    private String toHexM(Colour c) {
        switch (c) {
            case RED: return "#B04C48";     // Deeper red
            case BLUE: return "#6F8C99";    // Deeper blue
            case GREEN: return "#4DA64D";   // Deeper green
            case YELLOW: return "#D4D43B";  // Deeper yellow
            default: return "#777777";      // Neutral dark gray
        }
    }

    
    /*private Image getCardImage(Card card){
    	Image image;
    	
    	if(card.getName().equals("Ace")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/acehearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/acespade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/aceclub.jpeg");
    		else
    			image =new Image("/acediamond.jpg");
    	}
    	else if(card.getName().equals("Two")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/twohearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/twospade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/twoclub.jpg");
    		else
    			image =new Image("/twodiamond.jpg");
    		
    	}else if(card.getName().equals("Three")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/threehearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/threespade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/threeclub.jpg");
    		else
    			image =new Image("/threediamond.jpg");
    		
    	}else if(card.getName().equals("Four")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/fourhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/fourspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/fourclub.jpg");
    		else
    			image =new Image("/fourdiamond.jpg");
    		
    	}else if(card.getName().equals("Five")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/fivehearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/fivespade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/fiveclub.jpg");
    		else
    			image =new Image("/fivediamond.jpg");
    		
    	}else if(card.getName().equals("Six")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/sixhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/sixspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/sixclub.jpg");
    		else
    			image =new Image("/sixdiamond.jpg");
    		
    	}else if(card.getName().equals("Seven")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/sevenhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/sevenspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/sevenclub.jpg");
    		else
    			image =new Image("/sevendiamond.jpg");
    		
    	}else if(card.getName().equals("Eight")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/eighthearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/eightspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/eightclub.jpg");
    		else
    			image =new Image("/eightdiamond.jpg");
    		
    	}else if(card.getName().equals("Nine")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/ninehearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/ninespade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/nineclub.jpg");
    		else
    			image =new Image("/ninediamond.jpg");
    		
    	}else if(card.getName().equals("Ten")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/tenhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/tenspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/tenclub.jpg");
    		else
    			image =new Image("/tendiamond.jpg");
    		
    	}else if(card.getName().equals("Jack")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/jackhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/jackspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/jackclub.jpg");
    		else
    			image =new Image("/jackdiamond.jpg");
    		
    	}else if(card.getName().equals("Queen")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/queenhearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/queenspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/queenclub.jpg");
    		else
    			image =new Image("/queendiamond.jpg");
    		
    	}else if(card.getName().equals("King")){
    		Standard s= (Standard) card;
    		if(s.getSuit() == Suit.HEART)
    			image =new Image("/kinghearts.jpg");
    		else if(s.getSuit()== Suit.SPADE)
    			image =new Image("/kingspade.jpg");
    		else if(s.getSuit()== Suit.CLUB)
    			image =new Image("/kingclub.jpg");
    		else
    			image =new Image("/kingdiamond.jpg");
    		
    	}else if(card.getName().equals("MarbleBurner")){
    		image =new Image("/burner.png");
    		
    	}else if(card.getName().equals("MarbleSaver")){
    		image =new Image("/saver.png");
    	}else
    		image =new Image("");

    	return image;
    }*/
    
    
    private Image getCardImage(Card card) {
        String imagePath = getImagePath(card);

        // Check the cache first
        if (cardImageCache.containsKey(imagePath)) {
            return cardImageCache.get(imagePath);
        }

        // Load and cache
        Image image = new Image(imagePath);
        cardImageCache.put(imagePath, image);
        return image;
    }
    
    private String getImagePath(Card card) {
        if (card.getName().equals("MarbleBurner")) {
            return "/burner.png";
        }
        if (card.getName().equals("MarbleSaver")) {
            return "/saver.png";
        }

        if (card instanceof Standard) {
            Standard s = (Standard) card;
            Suit suit = s.getSuit();
            String suitName = "";

            if (suit == Suit.HEART) {
                suitName = "hearts";
            } else if (suit == Suit.SPADE) {
                suitName = "spades";
            } else if (suit == Suit.CLUB) {
                suitName = "clubs";
            } else if (suit == Suit.DIAMOND) {
                suitName = "diamonds";
            }
            
            return "/" + card.getName().toLowerCase() + suitName + ".png";
        }

        return ""; // fallback
    }


    
 // Method to display a custom alert
    private void displayAlert(String title, String message) {
        Stage alertStage = new Stage();
        alertStage.setTitle(title);

        Label label = new Label(message);
        Button closeButton = new Button("Continue");
        closeButton.setOnAction(event -> alertStage.close());

        BorderPane pane = new BorderPane();
        pane.setTop(label);
        pane.setCenter(closeButton);

        Scene scene = new Scene(pane, 400, 100);
        alertStage.setScene(scene);
        alertStage.show();
    }
    
    
    //method to edit split distance
    private void split() {
        Stage alertStage = new Stage();
        alertStage.initModality(Modality.APPLICATION_MODAL); // makes it blocking
        alertStage.setTitle("Split Distance");
        
        Label label = new Label("Enter the split distance");
        TextField inputField = new TextField();
        
        Button closeButton = new Button("Continue");
       
        
        closeButton.setOnAction(e -> {
        	try {
        		 int splitDistance = Integer.parseInt(inputField.getText().trim());
                 game.editSplitDistance(splitDistance);
                 alertStage.close();
			} catch (Exception e1) {
				displayAlert("", e1.getMessage());
			}
        });

        VBox layout = new VBox(10, label, inputField, closeButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        
        Scene scene = new Scene(layout, 400, 100);
        alertStage.setScene(scene);
        alertStage.showAndWait(); // blocks until closed
    }
    
    
    private void skipped() {
        Stage alertStage = new Stage();
        alertStage.initModality(Modality.APPLICATION_MODAL); // makes it blocking
        alertStage.setTitle("Your turn is skipped");
        
        Label label = new Label("A player has discarded one of your cards! Your turn is skipped");
        
        Button closeButton = new Button("OK");
       
        
        closeButton.setOnAction(e -> {
        	alertStage.close();
        });

        VBox layout = new VBox(10, label, closeButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        
        Scene scene = new Scene(layout, 600, 300);
        alertStage.setScene(scene);
        alertStage.showAndWait(); // blocks until closed
    }

    
    private void showTimedPopupThenRun(String message, Runnable afterAction) {
        Stage popup = new Stage();
        popup.setAlwaysOnTop(true);
        popup.setResizable(false);

        Label label = new Label(message);
        label.setStyle("-fx-font-size: 18px; -fx-text-fill: black; -fx-padding: 20px;");

        StackPane layout = new StackPane(label);
        layout.setStyle("-fx-background-color: white; -fx-border-color: black;");

        Scene scene = new Scene(layout);
        popup.setScene(scene);
        popup.setWidth(600);
        popup.setHeight(200);
        popup.setTitle("Invalid move!");
        popup.show();

        PauseTransition delay = new PauseTransition(Duration.seconds(4));
        delay.setOnFinished(e -> {
            popup.close();
            afterAction.run(); // Run the action after popup closes
        });
        delay.play();
    }
    
    private void play() {
        if (game.getPlayers().get(0).getSelectedCard() != null
                && game.getPlayers().get(0).getSelectedCard().getName().equals("Seven")
                && game.getPlayers().get(0).getSelectedMarbles().size() == 2) {
            split();
        }

        try {
            if (game.canPlayTurn()) {
                game.playPlayerTurn();
            }else{
            	skipped();
            }
            
            game.endPlayerTurn();
            showGameScreen(playerName, selectedAvatarPath);
            if (game.checkWin() != null) {
                showWinnerScreen(game.checkWin());
                return;
            }
            PauseTransition wait = new PauseTransition(Duration.seconds(6));
            wait.setOnFinished(e -> cpuplay(1));
            wait.play();

        } catch (GameException e) {
            showTimedPopupThenRun(e.getMessage(), () -> {
                game.endPlayerTurn();
                showGameScreen(playerName, selectedAvatarPath);
                if (game.checkWin() != null) {
                    showWinnerScreen(game.checkWin());
                    return;
                }
                PauseTransition wait = new PauseTransition(Duration.seconds(4));
                wait.setOnFinished(f -> cpuplay(1));
                wait.play();
            });
        }
    }

    
    
    private void cpuplay(int cpuIndex) {
        if (cpuIndex >= 4) {
            // After all CPUs, return to human player
            showGameScreen(playerName, selectedAvatarPath);
            return;
        }

        // Only CPU players (index 1, 2, 3)
        if (cpuIndex != 0) {
            if (game.canPlayTurn())
				try {
					game.playPlayerTurn();
				} catch (GameException e) {
					e.printStackTrace();
				}
               
            game.endPlayerTurn();
            
            // Update the screen
            showGameScreen(playerName, selectedAvatarPath);
            if(game.checkWin()!=null){
				showWinnerScreen(game.checkWin());
				return;
			}
        }

        // Wait 4 seconds before next CPU player
        PauseTransition wait = new PauseTransition(Duration.seconds(4));
        wait.setOnFinished(e -> cpuplay(cpuIndex + 1));
        wait.play();
    }
    
  //method to show trap 
    public static void showtrap() {
        Stage alertStage = new Stage();
        alertStage.initModality(Modality.APPLICATION_MODAL); // makes it blocking
        alertStage.setTitle("TRAP!");
        
        Label label = new Label("player has landed on a trap cell");
        
        
        Button closeButton = new Button("Continue");
       
        
        closeButton.setOnAction(e -> {
        	alertStage.close();
        });

        VBox layout = new VBox(10, label, closeButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        
        Scene scene = new Scene(layout, 400, 100);
        alertStage.setScene(scene);
        alertStage.showAndWait(); // blocks until closed
    }

 
    public static void main(String[] args) {
        launch(args);
    }
}